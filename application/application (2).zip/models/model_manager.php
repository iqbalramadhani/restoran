<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Model_manager extends CI_Model {
    
    
    
    function post($data){
       $this->db->insert('pegawai',$data);
       $id = $this->db->insert_id();
       $akun = array(
          'id_pegawai' => $id,
          'username' => $this->input->post('username',true),
          'password' => $this->input->post('password',true)
        );
        return $this->db->insert('akun',$akun);
    }

    function tampil_akun(){
        $query = "SELECT * FROM pegawai";
        $hasil = $this->db->query($query);
        return $hasil;
    }
    

    function hapus($id){
        $this->db->where('id_bahan',$id);
        $this->db->delete('bahan');
    }
}
